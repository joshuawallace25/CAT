document.getElementById("Login Form").addEventListener("login",function (event){
    event.preventDefault();

    const errorMessages= document.getElementById("errorMessages");
    errorMessages.innerHTML="";

    const name= document.getElementById("name".valueOf.trim());
const email = document.getElementById("password").value.trim();
   

    let isValid = true;
    let errors = [];

    if (name === ""){
        isValid = false;
        errors.push("Please enter your name");
    }


    });